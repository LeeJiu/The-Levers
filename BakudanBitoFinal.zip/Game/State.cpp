﻿#include "GameLib/Framework.h"

#include "Game/State.h"
#include "Game/StaticObject.h"
#include "Game/DynamicObject.h"
#include "SoundManager.h"
#include "Image.h"

using namespace GameLib;

namespace {

//스테이지 크기 정의
static const int WIDTH = 19;
static const int HEIGHT = 15;
////뵚뭙긬깋긽??
//static const int EXPLOSION_TIME = 180; //3뷳
//static const int EXPLOSION_LIFE = 60; //1뷳

//밙뱰긚긡?긙긢??
struct StageData{
	int mEnemyNum; //유령 수
	int mFloorRate; //바닥 비율
	int mLeverNum; //레버 개 수
};

static StageData gStageData[] = {
	{ 2, 70, 5, },
	{ 4, 60, 5, },
	{ 6, 50, 5, },
};

} //namespace{}

State::State( int stageID ) : 
mImage( 0 ),
mDynamicObjects( 0 ),
mDynamicObjectNumber( 0 ),
mStageID( stageID ){
	Framework f = Framework::instance(); //뚣궳돺뱗궔럊궎궻궳
	mStaticObjects.setSize( WIDTH, HEIGHT );

	mImage = new Image( "data/image/bakudanBitoImage.tga" );

	const StageData& stageData = gStageData[ mStageID ]; //stage id에 따른 스테이지 세팅
	int n = HEIGHT * WIDTH; //전체크기

	//바닥 할당할 배열
	unsigned* floorList = new unsigned[ n ];
	int floorNumber = 0; //0으로 초기화

	//벽 그리기
	for ( int y = 0; y < HEIGHT; ++y ){
		for ( int x = 0; x < WIDTH; ++x ){
			StaticObject& o = mStaticObjects( x, y );
			if ( x == 0 || ( x == WIDTH-1 ) ){
				o.setFlag( StaticObject::FLAG_WALL_H ); //세로벽 세팅
			}else if ( y == 2 ) {
				if( x ==6 ) {
					o.setFlag( StaticObject::FLAG_LIGHT1 ); //불빛1 세팅
				}else if( x ==8 ){
					o.setFlag( StaticObject::FLAG_LIGHT2 ); //불빛2 세팅
				}else if( x ==10 ){
					o.setFlag( StaticObject::FLAG_LIGHT3 ); //불빛3 세팅
				}else if( x ==12 ){
					o.setFlag( StaticObject::FLAG_LIGHT4 ); //불빛4 세팅
				}else if( x ==14 ){
					o.setFlag( StaticObject::FLAG_LIGHT5 ); //불빛5 세팅
				}else {
					o.setFlag( StaticObject::FLAG_WALL_W);	}//가로벽 세팅
			}else if ( y==0 || y ==1 || y ==3 ){
				o.setFlag( StaticObject::FLAG_WALL_W ); //가로벽 세팅
			}else{ //100까지 랜덤 숫자 발생
				if ( f.getRandom( 100 ) < stageData.mFloorRate  ){
					o.setFlag( StaticObject::FLAG_FLOOR );
					//바닥할당
					floorList[ floorNumber ] = ( x << 16 ) + y;
					++floorNumber;
				}else{
					o.setFlag( StaticObject::FLAG_HOLE ); //나머지는 구멍
				}
			}
		}
	}
	//레버 개수
	int LeverNum = stageData.mLeverNum;
	
	//배열에 할당
	for ( int i = 0; i < LeverNum; ++i ){
 		int swapped = f.getRandom( floorNumber - 1 - i ) + i; 
		//다시한번 생기지 않도록
		unsigned t = floorList[ i ];
		floorList[ i ] = floorList[ swapped ];
		floorList[ swapped ] = t;

		int x = floorList[ i ] >> 16;
		int y = floorList[ i ] & 0xffff;
		StaticObject& o = mStaticObjects( x, y );
		switch(i){
		case 0: 
			o.setFlag( StaticObject::FLAG_LEVER1 );
			break;
		case 1: 
			o.setFlag( StaticObject::FLAG_LEVER2 );
			break;
		case 2: 
			o.setFlag( StaticObject::FLAG_LEVER3 );
			break;
		case 3: 
			o.setFlag( StaticObject::FLAG_LEVER4 );
			break;
		case 4: 
			o.setFlag( StaticObject::FLAG_LEVER5 );
			break;
		default:
			HALT("can't be exist");
			break;
		}
	}
	SAFE_DELETE_ARRAY( floorList );

	//static object
	int playerNum = 1;
	int enemyNum = stageData.mEnemyNum;
	mDynamicObjectNumber = playerNum + enemyNum;
	mDynamicObjects = new DynamicObject[ mDynamicObjectNumber ];

	//P1
	mDynamicObjects[ 0 ].set( 1, 1, DynamicObject::TYPE_PLAYER );
	
	//적을 배치
	for ( int i = 0; i < enemyNum; ++i ){
 		int swapped = f.getRandom( floorNumber - 1 - i ) + i;
		unsigned t = floorList[ i ];
		floorList[ i ] = floorList[ swapped ];
		floorList[ swapped ] = t;

		int x = floorList[ i ] >> 16;
		int y = floorList[ i ] & 0xffff;
		mDynamicObjects[ playerNum + i ].set( x, y, DynamicObject::TYPE_ENEMY );
	}
	SAFE_DELETE_ARRAY( floorList );
}

State::~State(){
	SAFE_DELETE( mImage );
	SAFE_DELETE_ARRAY( mDynamicObjects );
}

void State::draw() const {
	//
	for ( int y = 0; y < HEIGHT; ++y ){
		for ( int x = 0; x < WIDTH; ++x ){
			mStaticObjects( x, y ).draw( x, y, mImage );
		}
	}
	//멟똧?됪
	for ( int i = 0; i < mDynamicObjectNumber; ++i ){
		mDynamicObjects[ i ].draw( mImage );
	}
	//뵚븮?됪
	for ( int y = 0; y < HEIGHT; ++y ){
		for ( int x = 0; x < WIDTH; ++x ){
			mStaticObjects( x, y ).drawExplosion( x, y, mImage );
		}
	}
}

void State::update(){
// 다이나믹 오브젝트 루프
	for ( int i = 0; i < mDynamicObjectNumber; ++i ){
		DynamicObject& o = mDynamicObjects[ i ];
		if ( o.isDead() ){ //움직이는 오브젝트가 죽었다면
			continue; //포문 넘김
		}
		//현재 셀을 취득
		int x, y;
		o.getCell( &x, &y );
		
		const StaticObject& so = mStaticObjects( x, y );
				if ( so.checkFlag( StaticObject::FLAG_HOLE ) ){ 
						wallsX[ wallNumber ] = x + i - 1;
						wallsY[ wallNumber ] = y + j - 1;
						++wallNumber;
					}
				}
			}
		}
		//구멍리스트를 넘겨서 다중처리
		o.move( holeX, holeY, holeNumber );
		//이동후의 위치에 주위 9물체 충돌판정하여 이런저런 반응
		for ( int i = 0; i < 3; ++i ){
			for ( int j = 0; j < 3; ++j ){
				StaticObject& so = mStaticObjects( x + i - 1, y + j - 1 );
				if ( o.isIntersectWall( x + i - 1, y + j - 1 ) ){ //触ってます 충돌처리
					if ( so.checkFlag( StaticObject::FLAG_FIRE_X | StaticObject::FLAG_FIRE_Y ) ){
						o.die(); //焼かれた 불탐
					}else if ( !so.checkFlag( StaticObject::FLAG_BRICK ) ){ //あらわになっているアイテムがあれば  아이템이 나와있는 상태라면
						if ( so.checkFlag( StaticObject::FLAG_ITEM_POWER ) ){
							so.resetFlag( StaticObject::FLAG_ITEM_POWER );
							++o.mBombPower;
						}else if ( so.checkFlag( StaticObject::FLAG_ITEM_BOMB ) ){
							so.resetFlag( StaticObject::FLAG_ITEM_BOMB );
							++o.mBombNumber;
						}
					}
				}
			}
		}
		//移動後セル番号を取得 이동후 셀 번호를 취득
		o.getCell( &x, &y );
		//爆弾を置く 폭탄을 놓는다
		if ( o.hasBombButtonPressed() ){ //爆弾設置ボタンが押されていて 폭탄설치 버튼이 눌려있어
			if ( bombNumber[ o.mPlayerID ] < o.mBombNumber ){ //爆弾最大値未満で 폭탄 최대 치 미만일때
				StaticObject& so = mStaticObjects( x, y );
				if ( !so.checkFlag( StaticObject::FLAG_BOMB ) ){ //爆弾がない 폭탄이엇ㅂ다
					so.setFlag( StaticObject::FLAG_BOMB );
					so.mBombOwner = &o;
					so.mCount = 0;

					//置いた爆弾位置を更新 놓여져잇는 폭탄위치갱신
					if ( o.mLastBombX[ 0 ] < 0 ){
						o.mLastBombX[ 0 ] = x;
						o.mLastBombY[ 0 ] = y;
					}else{
						o.mLastBombX[ 1 ] = x;
						o.mLastBombY[ 1 ] = y;
					}
					SoundManager::instance()->playSe( SoundManager::SE_SET_BOMB );
				}
			}
		}
	}
	//다음. 적과 플레이어의 접촉판정. 
	for ( int i = 0; i < mDynamicObjectNumber; ++i ){
		for ( int j = i + 1; j < mDynamicObjectNumber; ++j ){
			mDynamicObjects[ i ].doCollisionReactionToDynamic( &mDynamicObjects[ j ] );
		}
	}
}

bool State::hasCleared() const {
	//불이 다섯개 다 켜졌는지
	for ( int i = 0; i < mDynamicObjectNumber; ++i ){
		if ( mDynamicObjects[ i ].isEnemy() ){
			return false;
		}
	}
	return true;
}

bool State::isAlive( int playerID ) const {
	//궋귢궽맯궖궲궋귡
	for ( int i = 0; i < mDynamicObjectNumber; ++i ){
		if ( mDynamicObjects[ i ].mType == DynamicObject::TYPE_PLAYER ){
			if ( mDynamicObjects[ i ].mPlayerID == playerID ){
				return true;
			}
		}
	}
	return false;
}

